import os
print("What directory would you like to use?")
directory = input()
print("What is the name of your file?")
filename = input()
path = directory+filename
if os.path.isdir(directory):
  print('Directory exists')
if os.path.isfile(filename):
  print('File exists')
if os.path.exists(path):
  print('Path exists')
print('')
name = input()
print('')
add = input()
print('')
phone = input()
with open(path, 'w') as filehandle:
  filehandle.write(name)
  filehandle.write(add)
  filehandle.write(phone)
with open(path, 'r') as filehandle:
  read = filehandle.read()
  print(read)